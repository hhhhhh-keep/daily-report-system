---
name: daily-report-docx-template
description: 当需要将已验证的日报事实包和可选模型分析渲染为标准公文风格 Word 日报时使用。
---

# 日报 Word 模板

仅在 `daily-facts.json` 已通过规则 Skill 验证后使用。可选的 `daily-analysis.json` 也必须先通过证据门禁；本 Skill 只消费结构化输入并渲染，不计算人数、比率、名单或业务结论。

## 宿主运行协议

本 Skill 是可执行 Skill 包，不要求宿主机预装 Python 包。宿主应读取根目录 `manifest.json`，按其中的 `runtime_profile=daily-python-3.12-v1` 在受控运行环境中执行已声明的入口；禁止网络访问，也不得执行清单外脚本。输入、输出文件名和 JSON Schema 以清单中的 `contracts` 为准。若宿主不支持该运行档案，应明确返回“不支持脚本型 Skill”，不得退化为仅把本文当提示词执行。

使用 `scripts/render_daily_report.py` 消费固定锚点模板，并以 `scripts/audit_daily_report.py` 审计生成的 DOCX。模型分析缺失或验证失败时，仍生成 facts-only 基础报告：确定性驾驶舱、实名出勤名单和工作汇总保留，语义栏目显示待人工补充提示。
