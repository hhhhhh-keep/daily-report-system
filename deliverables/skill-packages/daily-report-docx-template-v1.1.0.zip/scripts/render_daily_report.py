"""Render a fixed-anchor daily report DOCX from validated facts and analysis."""

from __future__ import annotations

import argparse
from collections.abc import Mapping
from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


ANCHORS = ("DR_TITLE", "DR_META", "DR_DASHBOARD", "DR_ATTENDANCE", "DR_WORK_SUMMARY", "DR_PROJECTS", "DR_RISKS", "DR_ACTIONS")
FALLBACK_TEXT = "未调用模型或模型结果未通过校验，待人工补充"


def create_template(path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    document = Document()
    section = document.sections[0]
    section.orientation = WD_ORIENT.PORTRAIT
    section.page_width, section.page_height = Cm(21.0), Cm(29.7)
    section.top_margin, section.bottom_margin = Cm(3.7), Cm(3.5)
    section.left_margin, section.right_margin = Cm(2.8), Cm(2.6)
    normal = document.styles["Normal"]
    _set_font(normal, "仿宋_GB2312", 16)
    normal.paragraph_format.line_spacing = Pt(28)
    normal.paragraph_format.first_line_indent = Pt(32)
    heading = document.styles["Heading 1"]
    _set_font(heading, "黑体", 16)
    heading.paragraph_format.space_before, heading.paragraph_format.space_after = Pt(12), Pt(6)

    title = document.add_paragraph("DR_TITLE")
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_run_font(title.runs[0], "方正小标宋简体", 22, bold=True)
    meta = document.add_paragraph("DR_META")
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_run_font(meta.runs[0], "仿宋_GB2312", 12)
    dashboard = document.add_table(rows=1, cols=1)
    dashboard.autofit = False
    dashboard_cell = dashboard.cell(0, 0)
    dashboard_paragraph = dashboard_cell.paragraphs[0]
    dashboard_paragraph.text = "DR_DASHBOARD"
    dashboard_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_run_font(dashboard_paragraph.runs[0], "仿宋_GB2312", 12, color="FFFFFF", bold=True)
    _shade_cell(dashboard_cell, "1F4E78")
    for anchor in ("DR_ATTENDANCE", "DR_WORK_SUMMARY", "DR_PROJECTS", "DR_RISKS", "DR_ACTIONS"):
        paragraph = document.add_paragraph(anchor)
        _set_run_font(paragraph.runs[0], "仿宋_GB2312", 16)
    document.save(path)
    return path


def render_daily_report(template_path: Path, facts: Mapping[str, object], analysis: Mapping[str, object] | None, output_path: Path) -> Path:
    document = Document(template_path)
    metrics = _mapping(facts.get("metrics"))
    period = _mapping(facts.get("period"))
    replacements = {
        "DR_TITLE": "行一二部工作日报",
        "DR_META": f"报告日期：{period.get('start_date', date.today().isoformat())}    数据时区：{period.get('timezone', 'Asia/Shanghai')}",
        "DR_DASHBOARD": _dashboard(metrics),
        "DR_ATTENDANCE": _attendance(facts),
        "DR_WORK_SUMMARY": _work_summary(facts, analysis),
        "DR_PROJECTS": _semantic_section("三、重点项目及协同情况", analysis, "project_highlights", "summary", facts),
        "DR_RISKS": _semantic_section("四、风险问题及协调需求", analysis, "risk_items", "description", facts),
        "DR_ACTIONS": _semantic_section("五、次日关注及工作建议", analysis, "next_day_actions", "action", facts),
    }
    for paragraph in _all_paragraphs(document):
        if paragraph.text in replacements:
            _replace_paragraph(paragraph, replacements[paragraph.text])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    document.save(output_path)
    return output_path


def _dashboard(metrics: Mapping[str, object]) -> str:
    rate = metrics.get("submission_rate")
    rate_text = "待核验" if rate is None else f"{float(rate):.0%}"
    return "驾驶舱  |  应填 {expected}  实填 {submitted}  填报率 {rate}  未填 {missing}  全请 {full}  半请 {half}  风险 {risk}".format(
        expected=metrics.get("expected_people", "无"), submitted=metrics.get("submitted_people", "无"), rate=rate_text,
        missing=metrics.get("missing_people", "无"), full=metrics.get("full_day_leave_people", "无"),
        half=metrics.get("half_day_leave_people", "无"), risk=metrics.get("risk_or_blocked_count", "无"),
    )


def _attendance(facts: Mapping[str, object]) -> str:
    return "\n".join((
        "一、填报及出勤情况",
        f"未填日报：{_names(facts.get('missing_people'))}",
        f"全天请假：{_names(facts.get('full_day_leave_people'))}",
        f"半天请假：{_names(facts.get('half_day_leave_people'))}",
        f"待核验：{_names(facts.get('review_required_people'))}",
    ))


def _work_summary(facts: Mapping[str, object], analysis: Mapping[str, object] | None) -> str:
    if analysis is not None:
        summary = _mapping(analysis.get("work_summary")).get("summary")
        if isinstance(summary, str):
            return "二、当日工作总体情况\n" + summary
    metrics = _mapping(facts.get("metrics"))
    projects = _names(facts.get("project_candidates"), name_key="standard_name")
    collaborations = _names(facts.get("collaborations"), name_key="person_id")
    return "二、当日工作总体情况\n当日有效工作事项 {count} 项，风险或阻塞事项 {risk} 项。项目候选：{projects}。协同人员：{collaborations}。".format(
        count=metrics.get("effective_task_count", 0), risk=metrics.get("risk_or_blocked_count", 0), projects=projects, collaborations=collaborations,
    )


def _semantic_section(title: str, analysis: Mapping[str, object] | None, key: str, text_key: str, facts: Mapping[str, object]) -> str:
    if analysis is None:
        return f"{title}\n{FALLBACK_TEXT}"
    items = analysis.get(key)
    if not isinstance(items, list) or not items:
        return f"{title}\n无"
    texts = [item.get(text_key) for item in items if isinstance(item, Mapping) and isinstance(item.get(text_key), str)]
    return f"{title}\n" + ("；".join(texts) if texts else "无")


def _names(value: object, *, name_key: str = "name") -> str:
    if not isinstance(value, list) or not value:
        return "无"
    names = [item.get(name_key) for item in value if isinstance(item, Mapping) and isinstance(item.get(name_key), str)]
    return "、".join(names) if names else "无"


def _mapping(value: object) -> Mapping[str, object]:
    return value if isinstance(value, Mapping) else {}


def _replace_paragraph(paragraph: object, text: str) -> None:
    paragraph.clear()
    run = paragraph.add_run(text)
    _set_run_font(run, "仿宋_GB2312", 16)
    if text.startswith("行一二部"):
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _set_run_font(run, "方正小标宋简体", 22, bold=True)
    elif text.startswith("驾驶舱"):
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _set_run_font(run, "仿宋_GB2312", 12, color="FFFFFF", bold=True)
        _shade_paragraph(paragraph, "1F4E78")


def _set_font(style: object, name: str, size: int) -> None:
    style.font.name, style.font.size = name, Pt(size)
    style._element.rPr.rFonts.set(qn("w:eastAsia"), name)


def _set_run_font(run: object, name: str, size: int, *, color: str | None = None, bold: bool = False) -> None:
    run.font.name, run.font.size, run.bold = name, Pt(size), bold
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)


def _shade_paragraph(paragraph: object, fill: str) -> None:
    properties = paragraph._p.get_or_add_pPr()
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), fill)
    properties.append(shading)


def _shade_cell(cell: object, fill: str) -> None:
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), fill)
    cell._tc.get_or_add_tcPr().append(shading)


def _all_paragraphs(document: Document) -> list[object]:
    return list(document.paragraphs) + [paragraph for table in document.tables for row in table.rows for cell in row.cells for paragraph in cell.paragraphs]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--create-template", type=Path)
    arguments = parser.parse_args()
    if arguments.create_template:
        create_template(arguments.create_template)
