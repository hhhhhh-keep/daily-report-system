"""Structural audit for rendered daily report DOCX files."""

from __future__ import annotations

import zipfile
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT

from render_daily_report import ANCHORS


REQUIRED_HEADINGS = ("一、填报及出勤情况", "二、当日工作总体情况", "三、重点项目及协同情况", "四、风险问题及协调需求", "五、次日关注及工作建议")


@dataclass(frozen=True, slots=True)
class DocxAuditResult:
    ok: bool
    errors: tuple[str, ...]
    page_settings: Mapping[str, float]
    required_text_found: bool


def audit_daily_report(path: Path, facts: Mapping[str, object] | None = None) -> DocxAuditResult:
    errors: list[str] = []
    if not zipfile.is_zipfile(path):
        return DocxAuditResult(False, ("INVALID_DOCX_ZIP",), {}, False)
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            errors.append("CORRUPT_DOCX_ZIP")
    document = Document(path)
    text = "\n".join(paragraph.text for paragraph in _all_paragraphs(document))
    if any(anchor in text for anchor in ANCHORS):
        errors.append("UNCONSUMED_ANCHOR")
    required_text_found = all(heading in text for heading in REQUIRED_HEADINGS)
    if not required_text_found:
        errors.append("MISSING_REQUIRED_SECTION")
    if any(value in text for value in ("95人", "全员工作明细", "附件")):
        errors.append("FORBIDDEN_ATTACHMENT")
    if sum(len(table.rows) for table in document.tables) >= 20:
        errors.append("TOO_MANY_TABLE_ROWS")
    section = document.sections[0]
    page_settings = {"top_cm": section.top_margin.cm, "bottom_cm": section.bottom_margin.cm, "left_cm": section.left_margin.cm, "right_cm": section.right_margin.cm, "width_cm": section.page_width.cm, "height_cm": section.page_height.cm}
    if not (abs(page_settings["top_cm"] - 3.7) < 0.1 and abs(page_settings["bottom_cm"] - 3.5) < 0.1 and abs(page_settings["left_cm"] - 2.8) < 0.1 and abs(page_settings["right_cm"] - 2.6) < 0.1):
        errors.append("INVALID_PAGE_MARGINS")
    if section.orientation != WD_ORIENT.PORTRAIT or abs(section.page_width.cm - 21.0) >= 0.1 or abs(section.page_height.cm - 29.7) >= 0.1:
        errors.append("INVALID_PAGE_SIZE_OR_ORIENTATION")
    normal = document.styles["Normal"]
    heading = document.styles["Heading 1"]
    if normal.font.name != "仿宋_GB2312" or _size(normal) != 16 or heading.font.name != "黑体" or _size(heading) != 16:
        errors.append("INVALID_PUBLIC_DOCUMENT_FONTS")
    if _spacing(normal) != 28 or _indent(normal) != 32:
        errors.append("INVALID_PUBLIC_DOCUMENT_SPACING")
    if facts is not None:
        errors.extend(_missing_fact_names(text, facts))
    return DocxAuditResult(not errors, tuple(errors), page_settings, required_text_found)


def _all_paragraphs(document: Document) -> list[object]:
    return list(document.paragraphs) + [paragraph for table in document.tables for row in table.rows for cell in row.cells for paragraph in cell.paragraphs]


def _size(style: object) -> int | None:
    return round(style.font.size.pt) if style.font.size is not None else None


def _spacing(style: object) -> int | None:
    value = style.paragraph_format.line_spacing
    return round(value.pt) if hasattr(value, "pt") else None


def _indent(style: object) -> int | None:
    value = style.paragraph_format.first_line_indent
    return round(value.pt) if value is not None else None


def _missing_fact_names(text: str, facts: Mapping[str, object]) -> list[str]:
    errors: list[str] = []
    for fact_key, label in (("missing_people", "未填日报"), ("full_day_leave_people", "全天请假"), ("half_day_leave_people", "半天请假"), ("review_required_people", "待核验")):
        value = facts.get(fact_key)
        names = [item.get("name") for item in value if isinstance(item, Mapping) and isinstance(item.get("name"), str)] if isinstance(value, list) else []
        line = next((item for item in text.splitlines() if item.startswith(f"{label}：")), "")
        if not line or any(name not in line for name in names):
            errors.append("MISSING_FACT_NAME")
    return errors
