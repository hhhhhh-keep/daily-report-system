# 日报模板稳定接口

## 输入

- `daily-facts/1.1.0`：确定性指标、实名出勤、人员效能、正式项目、待关联项目、停滞项目和证据限制。
- `daily-analysis/1.1.0`：可选且已通过证据校验的总体判断、项目亮点、风险和次日建议。

## 模板权威

`assets/daily-report-template.docx` 是页面尺寸、页边距、Normal、Heading 1 和 Heading 2 样式的唯一权威。渲染期间只清理正文锚点并填入业务内容，不得重新设置页面或全局样式。

## 固定组件

- `DR_TITLE`：黑体18磅标题。
- `DR_META`：仿宋11磅报告日期与数据口径。
- `DR_DASHBOARD`：唯一允许使用的表格，2×4指标卡。
- `DR_ATTENDANCE`、`DR_WORK_SUMMARY`、`DR_PROJECTS`、`DR_RISKS`、`DR_ACTIONS`：渲染为标题和编号段落。

## 退化策略

AI结果缺失或校验失败时，只移除AI语义补充；确定性驾驶舱、实名出勤、人员效能、项目动态、风险候选和管理建议仍须完整输出。
