"""Deterministically render a concise leader-facing daily report DOCX."""

from __future__ import annotations

import argparse
from collections.abc import Mapping
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


ANCHORS = ("DR_TITLE", "DR_META", "DR_DASHBOARD", "DR_ATTENDANCE", "DR_WORK_SUMMARY",
           "DR_PROJECTS", "DR_RISKS", "DR_ACTIONS")
BLUE = "1F4E78"
LIGHT_BLUE = "D9EAF7"
LIGHT_GRAY = "F2F2F2"


def create_template(path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    document = Document()
    _configure_document(document)
    for anchor in ANCHORS:
        document.add_paragraph(anchor)
    document.save(path)
    return path


def render_daily_report(template_path: Path, facts: Mapping[str, object],
                        analysis: Mapping[str, object] | None, output_path: Path) -> Path:
    document = Document(template_path)
    _clear_body(document)
    _configure_document(document)
    period = _mapping(facts.get("period"))
    attendance = _mapping(facts.get("attendance_summary"))
    metrics = _mapping(facts.get("metrics"))

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _add_run(title, "行一二部工作日报", "方正小标宋简体", 22, bold=True)
    meta = document.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _add_run(meta, f"报告日期：{period.get('start_date', '未提供')}    数据时区：{period.get('timezone', 'Asia/Shanghai')}",
             "仿宋_GB2312", 12)

    _dashboard(document, attendance, metrics, _mapping(facts.get("status_distribution")))
    _heading(document, "一、整体判断")
    _body(document, _overall_judgment(attendance, metrics, analysis))

    _heading(document, "二、填报与出勤情况")
    _attendance_table(document, attendance)

    _heading(document, "三、人员效能分析")
    _efficiency_table(document, facts.get("efficiency_summary"))
    _body(document, "说明：事项数量仅用于观察当日工作结构，不直接等同于绩效高低；请假人员不与全天出勤人员按绝对数量简单比较。", italic=True)

    _heading(document, "四、项目动态及协同情况")
    _subheading(document, "（一）当日正式项目动态")
    _formal_projects(document, facts.get("formal_project_dynamics"), analysis)
    _subheading(document, "（二）日报识别待关联项目")
    _unlinked_projects(document, facts.get("unlinked_project_dynamics"))
    _subheading(document, "（三）超过3个工作日无动态项目")
    _stale_projects(document, facts.get("stale_project_alerts"))
    for limitation in _string_list(_mapping(facts.get("data_quality")).get("limitations")):
        _body(document, f"数据口径说明：{limitation}", italic=True)

    _heading(document, "五、次工作日管理关注")
    _management_actions(document, facts, analysis)
    if analysis is None:
        _body(document, "注：本报告未采用AI语义补充，以上内容均由确定性规则和原始证据生成。", italic=True)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    document.save(output_path)
    return output_path


def _configure_document(document: Document) -> None:
    section = document.sections[0]
    section.orientation = WD_ORIENT.PORTRAIT
    section.page_width, section.page_height = Cm(21.0), Cm(29.7)
    section.top_margin, section.bottom_margin = Cm(2.5), Cm(2.4)
    section.left_margin, section.right_margin = Cm(2.6), Cm(2.4)
    normal = document.styles["Normal"]
    _set_style_font(normal, "仿宋_GB2312", 14)
    normal.paragraph_format.line_spacing = Pt(24)
    normal.paragraph_format.space_after = Pt(3)
    normal.paragraph_format.first_line_indent = Pt(28)
    heading = document.styles["Heading 1"]
    _set_style_font(heading, "黑体", 16)
    heading.paragraph_format.space_before = Pt(10)
    heading.paragraph_format.space_after = Pt(5)
    heading.paragraph_format.keep_with_next = True


def _dashboard(document: Document, attendance: Mapping[str, object], metrics: Mapping[str, object],
               status: Mapping[str, object]) -> None:
    labels = ("应填写", "17:30已填", "22:00已填", "请假", "未填写", "有效事项", "完成事项", "阻塞事项")
    leave_count = len(_list(attendance.get("full_day_leave_people"))) + len(_list(attendance.get("half_day_leave_people")))
    values = (attendance.get("expected_people"), attendance.get("submitted_by_1730_people"),
              attendance.get("submitted_by_2200_people"), leave_count,
              len(_list(attendance.get("missing_people"))), metrics.get("effective_task_count", 0),
              status.get("completed", 0), status.get("blocked", metrics.get("risk_or_blocked_count", 0)))
    table = document.add_table(rows=2, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for index, (label, value) in enumerate(zip(labels, values)):
        cell = table.cell(index // 4, index % 4)
        cell.width = Cm(4.0)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        _shade_cell(cell, BLUE)
        paragraph = cell.paragraphs[0]
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.paragraph_format.first_line_indent = Pt(0)
        paragraph.paragraph_format.space_after = Pt(0)
        _add_run(paragraph, label + "\n", "微软雅黑", 9, color="FFFFFF")
        _add_run(paragraph, _display(value), "宋体", 16, color="FFFFFF", bold=True)
    document.add_paragraph().paragraph_format.space_after = Pt(0)


def _overall_judgment(attendance: Mapping[str, object], metrics: Mapping[str, object],
                      analysis: Mapping[str, object] | None) -> str:
    if analysis is not None:
        summary = _mapping(analysis.get("overall_judgment")).get("summary")
        if not isinstance(summary, str):
            summary = _mapping(analysis.get("work_summary")).get("summary")
        if isinstance(summary, str) and summary.strip():
            return summary.strip()
    expected = attendance.get("expected_people")
    final_rate = _percent(attendance.get("submitted_by_2200_rate"))
    missing = len(_list(attendance.get("missing_people")))
    risks = metrics.get("risk_or_blocked_count", 0)
    return f"当日应填写{_display(expected)}人，截至22:00填报率{final_rate}，未填写{missing}人；识别风险或阻塞事项{risks}项。管理重点为督促未填人员补报，并跟进项目阻塞与超期无动态事项。"


def _attendance_table(document: Document, attendance: Mapping[str, object]) -> None:
    rows = [
        ("应填写人数", _display(attendance.get("expected_people"))),
        ("截至17:30", f"已填写{_display(attendance.get('submitted_by_1730_people'))}人，填写率{_percent(attendance.get('submitted_by_1730_rate'))}"),
        ("截至22:00", f"已填写{_display(attendance.get('submitted_by_2200_people'))}人，填写率{_percent(attendance.get('submitted_by_2200_rate'))}"),
        ("未填写", _names(attendance.get("missing_people"))),
        ("全天请假", _names(attendance.get("full_day_leave_people"))),
        ("半天请假", _names(attendance.get("half_day_leave_people"))),
        ("待核验", _names(attendance.get("review_required_people"))),
    ]
    _key_value_table(document, rows)


def _efficiency_table(document: Document, value: object) -> None:
    items = _list(value)
    if not items:
        _body(document, "当日无可统计的人员工作事项。")
        return
    table = _table(document, ("姓名", "事项", "完成", "进行中", "阻塞", "项目", "主导/协同"),
                   (2.4, 1.6, 1.6, 1.8, 1.6, 1.6, 5.4))
    for item in items[:10]:
        row = table.add_row().cells
        values = (item.get("name"), item.get("task_count"), item.get("completed_task_count"),
                  item.get("in_progress_task_count"), item.get("blocked_task_count"), item.get("project_count"),
                  f"主导{_display(item.get('lead_task_count'))}/协同{_display(item.get('collaboration_task_count'))}")
        _fill_row(row, values)


def _formal_projects(document: Document, value: object, analysis: Mapping[str, object] | None) -> None:
    items = _list(value)
    if not items:
        _body(document, "当日无已关联正式项目动态。")
        return
    highlights = {item.get("project_id"): item.get("summary") for item in _list(analysis.get("project_highlights") if analysis else None)}
    table = _table(document, ("项目", "状态/阶段", "负责人", "当日人员", "当日动态"), (3.0, 2.8, 1.8, 3.1, 5.3))
    for item in items:
        people = "主导：" + _join(item.get("lead_people")) + "；协同：" + _join(item.get("collaborator_people"))
        outputs = highlights.get(item.get("project_id")) or _join(item.get("outputs"))
        values = (item.get("project_name"), f"{_display(item.get('state'))}/{_display(item.get('current_stage'))}",
                  item.get("owner_name") or "未维护", people, outputs or "有事项记录，未形成明确产出")
        _fill_row(table.add_row().cells, values)


def _unlinked_projects(document: Document, value: object) -> None:
    items = _list(value)
    if not items:
        _body(document, "无。")
        return
    table = _table(document, ("候选项目", "涉及人员", "事项数", "处理建议"), (4.2, 4.0, 2.0, 5.8))
    for item in items:
        people = sorted(set((*_string_list(item.get("lead_people")), *_string_list(item.get("collaborator_people")))))
        _fill_row(table.add_row().cells, (item.get("project_name"), _join(people),
                                         item.get("task_count"), "核对项目维护主数据后确认关联关系"))


def _stale_projects(document: Document, value: object) -> None:
    items = _list(value)
    if not items:
        _body(document, "无。")
        return
    table = _table(document, ("项目", "负责人", "最近动态", "无动态工作日", "当前状态"), (4.0, 2.5, 3.0, 2.5, 4.0))
    for item in items:
        _fill_row(table.add_row().cells, (item.get("project_name"), item.get("owner_name") or "未维护",
                                         item.get("latest_report_date"), item.get("inactive_workdays"), item.get("state")))


def _management_actions(document: Document, facts: Mapping[str, object], analysis: Mapping[str, object] | None) -> None:
    actions = [(item.get("summary") or item.get("action")) for item in _list(analysis.get("next_day_actions") if analysis else None) if item.get("summary") or item.get("action")]
    risks = [(item.get("summary") or item.get("description")) for item in _list(analysis.get("risk_items") if analysis else None) if item.get("summary") or item.get("description")]
    if not actions:
        attendance = _mapping(facts.get("attendance_summary"))
        missing = _names(attendance.get("missing_people"))
        if missing != "无":
            actions.append(f"督促未填人员补报：{missing}。")
        for item in _list(facts.get("stale_project_alerts")):
            actions.append(f"核查{item.get('project_name')}连续{item.get('inactive_workdays')}个工作日无日报动态的原因。")
        for item in _list(facts.get("risk_candidates")):
            risk = item.get("risk") or item.get("blocker")
            if risk:
                risks.append(str(risk))
    for risk in risks:
        _body(document, f"风险关注：{risk}")
    for action in actions:
        _body(document, f"工作建议：{action}")
    if not risks and not actions:
        _body(document, "当日无明确风险或需升级协调事项，次工作日按既定计划推进。")


def _heading(document: Document, text: str) -> None:
    paragraph = document.add_paragraph(style="Heading 1")
    paragraph.paragraph_format.first_line_indent = Pt(0)
    _add_run(paragraph, text, "黑体", 16)


def _subheading(document: Document, text: str) -> None:
    paragraph = document.add_paragraph()
    paragraph.paragraph_format.first_line_indent = Pt(0)
    paragraph.paragraph_format.keep_with_next = True
    _add_run(paragraph, text, "楷体_GB2312", 14, bold=True)


def _body(document: Document, text: str, *, italic: bool = False) -> None:
    paragraph = document.add_paragraph()
    run = _add_run(paragraph, text, "仿宋_GB2312", 14)
    run.italic = italic


def _key_value_table(document: Document, rows: list[tuple[str, str]]) -> None:
    table = _table(document, ("项目", "情况"), (3.2, 12.8))
    for label, value in rows:
        _fill_row(table.add_row().cells, (label, value))


def _table(document: Document, headers: tuple[str, ...], widths: tuple[float, ...]):
    table = document.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for index, (header, width) in enumerate(zip(headers, widths)):
        cell = table.rows[0].cells[index]
        cell.width = Cm(width)
        _shade_cell(cell, LIGHT_BLUE)
        _set_cell_text(cell, header, bold=True, center=True)
    table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
    return table


def _fill_row(cells: object, values: tuple[object, ...]) -> None:
    for cell, value in zip(cells, values):
        _set_cell_text(cell, _display(value), center=not isinstance(value, str) or len(value) < 12)


def _set_cell_text(cell: object, text: str, *, bold: bool = False, center: bool = False) -> None:
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    paragraph = cell.paragraphs[0]
    paragraph.clear()
    paragraph.paragraph_format.first_line_indent = Pt(0)
    paragraph.paragraph_format.line_spacing = Pt(18)
    paragraph.paragraph_format.space_after = Pt(0)
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.LEFT
    _add_run(paragraph, text, "仿宋_GB2312", 10.5, bold=bold)


def _clear_body(document: Document) -> None:
    body = document._element.body
    for child in list(body):
        if child.tag != qn("w:sectPr"):
            body.remove(child)


def _set_style_font(style: object, name: str, size: float) -> None:
    style.font.name, style.font.size = name, Pt(size)
    style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), name)


def _add_run(paragraph: object, text: str, font: str, size: float, *, color: str | None = None,
             bold: bool = False):
    run = paragraph.add_run(text)
    run.font.name, run.font.size, run.bold = font, Pt(size), bold
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), font)
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    return run


def _shade_cell(cell: object, fill: str) -> None:
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), fill)
    cell._tc.get_or_add_tcPr().append(shading)


def _mapping(value: object) -> Mapping[str, object]:
    return value if isinstance(value, Mapping) else {}


def _list(value: object) -> list[Mapping[str, object]]:
    return [item for item in value if isinstance(item, Mapping)] if isinstance(value, list) else []


def _names(value: object) -> str:
    return _join([item.get("name") for item in _list(value) if item.get("name")])


def _join(value: object) -> str:
    items = value if isinstance(value, (list, tuple, set)) else []
    texts = [str(item) for item in items if item not in (None, "")]
    return "、".join(texts) if texts else "无"


def _string_list(value: object) -> list[str]:
    return [str(item) for item in value if item not in (None, "")] if isinstance(value, (list, tuple, set)) else []


def _display(value: object) -> str:
    return "无" if value in (None, "") else str(value)


def _percent(value: object) -> str:
    return "待核验" if value is None else f"{float(value):.2%}"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--create-template", type=Path)
    arguments = parser.parse_args()
    if arguments.create_template:
        create_template(arguments.create_template)
