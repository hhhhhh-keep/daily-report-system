---
name: daily-report-docx-template
description: 将日报规则 Skill 生成的确定性事实和可选的证据校验AI分析，渲染为固定格式、适合领导阅读的Word日报。
---

# 日报 Word 模板

本 Skill 只负责排版，不访问数据库或网络，不重新计算指标。输入必须是规则 Skill 生成并通过 Schema 校验的 `daily-facts.json`；`daily-analysis.json` 为可选增强输入。

## 固定流程

1. 宿主读取 `manifest.json`，按 `runtime_profile=daily-python-3.12-v1` 启动隔离运行时。
2. 使用 `assets/daily-report-template.docx` 和 `scripts/run_render_docx.py` 生成 `report.docx`。
3. 使用 `scripts/audit_daily_report.py` 校验标题、章节、实名名单、页面设置和模板锚点。
4. AI结果缺失或未通过证据校验时，只忽略AI补充；填报、出勤、人员效能、项目动态、超期提醒和管理建议仍必须完整输出。

## 固定报告结构

1. 标题与报告日期；
2. 简洁驾驶舱；
3. 整体判断；
4. 填报与出勤情况（含应填、17:30、22:00和实名名单）；
5. 人员效能分析；
6. 正式项目动态、待关联项目、超过3个工作日无动态项目；
7. 次工作日管理关注。

版式细则见 [references/layout.md](references/layout.md)。不得出现“领导版”、假数据、占位人名或“待人工补充”空章节。
