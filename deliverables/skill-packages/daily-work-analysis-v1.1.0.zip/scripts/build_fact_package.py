"""Build the stable, model-independent fact object for a daily report."""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import date
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from calculate_daily_metrics import PersonClassification, classify_people, deduplicated_tasks, calculate_daily_metrics
from package_contract import DataPackage


_SCHEMA_PATH = Path(__file__).resolve().parents[1] / "schemas" / "daily-facts.schema.json"


def canonical_json(value: object) -> bytes:
    """Canonical JSON bytes for repeatable artifact generation."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _person_fact(item: PersonClassification) -> dict[str, object]:
    return {
        "person_id": item.person.person_id, "name": item.person.name,
        "work_period_status": item.work_period_status, "review_reason": item.review_reason,
        "source_record_id": item.source_record_id,
    }


def _deduplicated_relations(package: DataPackage, task_ids: set[str]) -> list[dict[str, object]]:
    selected: dict[tuple[str, str, str], object] = {}
    for relation in package.task_relations:
        if relation.task_id not in task_ids:
            continue
        key = (relation.task_id, relation.person_id, relation.role)
        previous = selected.get(key)
        if previous is None or _relation_key(relation) < _relation_key(previous):
            selected[key] = relation
    return [
        {
            "task_id": relation.task_id, "person_id": relation.person_id, "role": relation.role,
            "relation_type": relation.relation_type, "evidence_id": relation.evidence_id,
            "parent_task_id": relation.parent_task_id, "related_task_id": relation.related_task_id,
        }
        for _, relation in sorted(selected.items())
    ]


def _relation_key(relation: object) -> tuple[str, ...]:
    return (
        relation.relation_type, relation.evidence_id, relation.parent_task_id or "",
        relation.related_task_id or "", relation.relation_id,
    )


def build_daily_facts(package: DataPackage, report_date: date) -> dict[str, object]:
    """Return only schema-validated facts in deterministic key and array order."""
    metrics = calculate_daily_metrics(package, report_date)
    classifications = classify_people(package, report_date)
    tasks = deduplicated_tasks(package, report_date)
    tasks_by_id = {task.task_id: task for task in tasks}
    report_by_id = {report.report_id: report for report in package.reports if report.date == report_date.isoformat()}
    projects_by_id = {project.project_id: project for project in package.projects}

    people_by_state = {
        state: [_person_fact(item) for item in classifications if item.state == state]
        for state in ("missing", "full_day_leave", "half_day_leave", "review_required")
    }
    work_composition = [
        {
            "task_id": task.task_id, "report_id": task.report_id, "person_id": report_by_id[task.report_id].person_id,
            "time_period": task.time_period, "task_type": task.task_type,
            "project_candidate_id": task.project_candidate_id, "status": task.status,
            "output": task.output, "next_step": task.next_step,
        }
        for task in tasks if task.report_id in report_by_id
    ]
    project_candidates = [
        {
            "project_id": project_id,
            "standard_name": projects_by_id[project_id].standard_name,
            "candidate_names": list(sorted(projects_by_id[project_id].candidate_names)),
            "merge_status": projects_by_id[project_id].merge_status,
            "manual_confirmation_status": projects_by_id[project_id].manual_confirmation_status,
        }
        for project_id in sorted({task.project_candidate_id for task in tasks if task.project_candidate_id in projects_by_id})
    ]
    risk_candidates = [
        {
            "task_id": task.task_id, "person_id": report_by_id[task.report_id].person_id,
            "status": task.status, "risk": task.risk, "blocker": task.blocker,
        }
        for task in tasks if task.report_id in report_by_id
        and (task.status == "blocked" or task.risk is not None or task.blocker is not None)
    ]
    attendance_source_ids = {
        item.source_record_id for item in package.attendance
        if item.date == report_date.isoformat()
    }
    evidence_ids = (
        {report.snapshot_id for report in report_by_id.values()}
        | {relation["evidence_id"] for relation in _deduplicated_relations(package, set(tasks_by_id))}
        | {snapshot["snapshot_id"] for snapshot in package.source_snapshots if snapshot["source_record_id"] in attendance_source_ids}
    )
    evidence = [
        {"evidence_id": snapshot["snapshot_id"], "raw_text": snapshot["raw_record"]}
        for snapshot in sorted(package.source_snapshots, key=lambda item: item["snapshot_id"])
        if snapshot["snapshot_id"] in evidence_ids
    ]
    status_distribution = {
        status: sum(task.status == status for task in tasks)
        for status in ("blocked", "completed", "in_progress", "planned")
    }
    facts: dict[str, object] = {
        "data_contract_version": package.manifest.data_contract_version,
        "period": {"start_date": report_date.isoformat(), "end_date": report_date.isoformat(), "timezone": package.manifest.timezone},
        "metrics": asdict(metrics),
        "missing_people": people_by_state["missing"],
        "full_day_leave_people": people_by_state["full_day_leave"],
        "half_day_leave_people": people_by_state["half_day_leave"],
        "review_required_people": people_by_state["review_required"],
        "work_composition": work_composition,
        "status_distribution": status_distribution,
        "project_candidates": project_candidates,
        "collaborations": _deduplicated_relations(package, set(tasks_by_id)),
        "risk_candidates": risk_candidates,
        "evidence": evidence,
    }
    _validate_facts(facts)
    return facts


def _validate_facts(facts: dict[str, object]) -> None:
    schema = json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(facts), key=lambda error: list(error.absolute_path))
    if errors:
        raise ValueError("daily-facts schema validation failed: " + "; ".join(error.message for error in errors))
