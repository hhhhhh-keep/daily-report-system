"""Validation gate for evidence-bound model analysis results."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from package_contract import ValidationIssue


_SCHEMA_PATH = Path(__file__).resolve().parents[1] / "schemas" / "daily-analysis.schema.json"


@dataclass(frozen=True, slots=True)
class AnalysisValidationResult:
    analysis: Mapping[str, object] | None
    errors: tuple[ValidationIssue, ...]

    @property
    def ok(self) -> bool:
        return not self.errors

    @property
    def error_codes(self) -> tuple[str, ...]:
        return tuple(issue.code for issue in self.errors)


def validate_analysis_result(daily_facts: Mapping[str, object], candidate: object) -> AnalysisValidationResult:
    """Accept only schema-valid output whose references are present in daily facts."""
    errors: list[ValidationIssue] = []
    errors.extend(_schema_errors(candidate))
    if not isinstance(candidate, Mapping):
        return AnalysisValidationResult(None, tuple(errors))

    if _contains_key(candidate, "metrics"):
        errors.append(_issue("METRICS_MUTATED", "metrics", "Model output may not contain deterministic metrics"))

    known_evidence = _known_values(daily_facts, "evidence_id")
    known_people = _known_values(daily_facts, "person_id")
    known_projects = _known_values(daily_facts, "project_id") | _known_values(daily_facts, "project_candidate_id")
    errors.extend(_unknown_reference_errors(candidate, "evidence_ids", known_evidence, "UNKNOWN_EVIDENCE_ID"))
    errors.extend(_unknown_reference_errors(candidate, "person_ids", known_people, "UNKNOWN_PERSON_ID"))
    errors.extend(_unknown_reference_errors(candidate, "project_id", known_projects, "UNKNOWN_PROJECT_ID"))
    errors.extend(_missing_evidence_errors(candidate))

    return AnalysisValidationResult(None if errors else dict(candidate), tuple(errors))


def _schema_errors(candidate: object) -> list[ValidationIssue]:
    schema = json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))
    validator = Draft202012Validator(schema)
    return [
        _issue("SCHEMA_INVALID", "/".join(str(part) for part in error.absolute_path), error.message)
        for error in sorted(validator.iter_errors(candidate), key=lambda item: list(item.absolute_path))
    ]


def _known_values(value: object, key: str) -> set[str]:
    values: set[str] = set()
    if isinstance(value, Mapping):
        for name, item in value.items():
            if name == key and isinstance(item, str):
                values.add(item)
            values.update(_known_values(item, key))
    elif _is_list(value):
        for item in value:
            values.update(_known_values(item, key))
    return values


def _unknown_reference_errors(candidate: Mapping[str, object], key: str, known: set[str], code: str) -> list[ValidationIssue]:
    errors: list[ValidationIssue] = []
    for path, value in _references(candidate, key):
        values = value if _is_list(value) else (value,)
        for item in values:
            if isinstance(item, str) and item not in known:
                errors.append(_issue(code, path, f"Unknown {key}: {item}"))
    return errors


def _references(value: object, key: str, path: str = "") -> list[tuple[str, object]]:
    references: list[tuple[str, object]] = []
    if isinstance(value, Mapping):
        for name, item in value.items():
            item_path = f"{path}/{name}" if path else name
            if name == key:
                references.append((item_path, item))
            references.extend(_references(item, key, item_path))
    elif _is_list(value):
        for index, item in enumerate(value):
            references.extend(_references(item, key, f"{path}/{index}"))
    return references


def _missing_evidence_errors(candidate: Mapping[str, object]) -> list[ValidationIssue]:
    errors: list[ValidationIssue] = []
    for section in ("risk_items", "next_day_actions"):
        items = candidate.get(section)
        if not _is_list(items):
            continue
        for index, item in enumerate(items):
            if isinstance(item, Mapping) and not item.get("evidence_ids"):
                errors.append(_issue("MISSING_EVIDENCE", f"{section}/{index}/evidence_ids", f"{section} items require evidence_ids"))
    return errors


def _contains_key(value: object, key: str) -> bool:
    return bool(_references(value, key))


def _is_list(value: object) -> bool:
    return isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray))


def _issue(code: str, path: str, message: str) -> ValidationIssue:
    return ValidationIssue(code=code, path=path, message=message)
