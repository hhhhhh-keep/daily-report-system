---
name: daily-work-analysis
description: 基于受控日报数据包生成可追溯、可校验的日报管理事实与语义分析；适用于日报填报、出勤、人员工作事项、项目动态、协同、风险和次日关注分析。
---

# 日报规则分析

本 Skill 只分析宿主提供的受控 DataPackage，不访问数据库或网络，不生成 Word。详细业务口径见 [references/rules.md](references/rules.md)。

## 固定执行顺序

1. 读取根目录 `manifest.json`，由宿主按 `runtime_profile=daily-python-3.12-v1` 启动隔离运行时。
2. 执行 `scripts/run_prepare_facts.py`，校验数据包并生成 `daily-facts.json`。
3. 所有人数、比率、事项数、项目停滞工作日数均以 `daily-facts.json` 为准，模型不得重算或覆盖。
4. 如宿主启用大模型，只向模型提供事实包；模型仅生成 `overall_judgment`、`efficiency_insights`、`project_highlights`、`risk_items`、`next_day_actions`，每项必须引用有效 `evidence_ids`。
5. 执行 `scripts/run_validate_analysis.py`。模型结果未通过 Schema 或证据校验时，丢弃模型结果，但仍将完整确定性事实交给模板 Skill。

## 必须产生的确定性事实

- `attendance_summary`：应填人数、17:30/22:00提交人数及比率、未填/全天请假/半天请假/待核验实名名单。
- `efficiency_summary`：逐人事项数、完成/进行中/阻塞数、涉及项目数。仅作管理观察，不直接等同绩效排名。
- `formal_project_dynamics`：正式项目状态、阶段、负责人、当天主导/协同人员、事项与产出及证据。
- `unlinked_project_dynamics`：日报出现但尚未与正式项目关联的候选事项。
- `stale_project_alerts`：正式在管项目超过阈值工作日无日报动态的关注项。

## 阻断原则

- 不得编造人员、项目、阶段、产出、风险或证据 ID。
- 全天请假不要求任务且不计未填；半天请假只核验另一个应工作时段。
- `first_submitted_at` 用于17:30口径；修改不得改变首次提交判定。
- 项目状态来自项目维护快照；历史快照若为重建值，必须保留 `snapshot_origin=reconstructed`。
- 模型失败不得导致报告关键章节为空；模板必须使用事实包生成完整基础报告。
- 引用 `snapshot_origin=reconstructed` 项目的语义结论必须填写 `limitation_note`，明确该状态为事后重建，不得当作分析日实时快照。
